# 🌐 Azure Portal Deployment Guide
## Step-by-Step Manual Deployment

### 🎯 **For Microsoft Imagine Cup 2026**

---

## 📋 **Prerequisites**

1. **Azure Account**: https://azure.microsoft.com/en-us/free/students/
2. **GitHub Repository**: Your AgriSync code pushed to GitHub
3. **Supabase Account**: Database already configured

---

## 🚀 **Step 1: Deploy Backend (Azure App Service)**

### 1.1 Create Web App
1. **Login**: https://portal.azure.com
2. **Click**: "Create a resource"
3. **Search**: "Web App" → Select
4. **Configure**:
   - **Subscription**: Azure for Students
   - **Resource Group**: Create new "agrisync-rg"
   - **Name**: `agrisync-backend-2026` (must be unique)
   - **Publish**: Code
   - **Runtime Stack**: Node.js 18 LTS
   - **Operating System**: Linux
   - **Region**: East US
   - **Pricing Plan**: B1 Basic (Free tier eligible)

5. **Click**: "Review + Create" → "Create"

### 1.2 Configure Environment Variables
1. **Go to**: Your new App Service
2. **Settings** → **Configuration**
3. **Application Settings** → **New application setting**
4. **Add these variables**:
   ```
   PORT = 8080
   JWT_SECRET = agrisync_jwt_secret_key_2024
   NODE_ENV = production
   DB_PATH = ./database/agrisync.db
   OPENAI_API_KEY = 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
   WEBSITE_NODE_DEFAULT_VERSION = 18.17.0
   ```
5. **Click**: "Save"

### 1.3 Deploy Code
1. **Deployment** → **Deployment Center**
2. **Source**: Local Git or GitHub
3. **If GitHub**:
   - Authorize GitHub
   - Select your repository
   - Branch: main
   - Build provider: App Service build service
4. **If Local Git**:
   - Copy the Git URL
   - Push your `server` folder content

**Your backend URL**: `https://agrisync-backend-2026.azurewebsites.net`

---

## 🚀 **Step 2: Deploy Frontend (Azure Static Web Apps)**

### 2.1 Create Static Web App
1. **Create a resource** → Search "Static Web Apps"
2. **Configure**:
   - **Subscription**: Azure for Students
   - **Resource Group**: agrisync-rg
   - **Name**: `agrisync-frontend-2026`
   - **Plan Type**: Free
   - **Region**: East US 2
   - **Source**: GitHub
   - **GitHub Account**: Authorize and select
   - **Repository**: Your AgriSync repo
   - **Branch**: main
   - **Build Presets**: React
   - **App location**: `client`
   - **Output location**: `build`

3. **Click**: "Review + Create" → "Create"

### 2.2 Configure Environment Variables
1. **Go to**: Your Static Web App
2. **Settings** → **Configuration**
3. **Add these variables**:
   ```
   REACT_APP_API_URL = https://agrisync-backend-2026.azurewebsites.net
   REACT_APP_SUPABASE_URL = https://uqarhxopmffoyrcndccx.supabase.co
   REACT_APP_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVxYXJoeG9wbWZmb3lyY25kY2N4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcwMjYxNTksImV4cCI6MjA4MjYwMjE1OX0.eBxBSighvwEXFs2Xck93qY5sAQKb-GLqmQrRNQ054JQ
   ```

**Your frontend URL**: `https://agrisync-frontend-2026.azurestaticapps.net`

---

## 🚀 **Step 3: Final Configuration**

### 3.1 Update CORS
1. **Edit**: `server/index.js`
2. **Update CORS origins**:
   ```javascript
   origin: process.env.NODE_ENV === 'production' 
     ? ['https://agrisync-frontend-2026.azurestaticapps.net']
     : ['http://localhost:3000'],
   ```
3. **Redeploy**: Backend with updated CORS

### 3.2 Test Deployment
1. **Visit**: Your frontend URL
2. **Test**: All functionality
3. **Check**: Browser console for errors
4. **Verify**: Supabase connection works

---

## 🏆 **Imagine Cup Benefits**

### What You've Achieved:
- ✅ **Enterprise Architecture**: Azure App Service + Static Web Apps
- ✅ **Global CDN**: Worldwide fast loading
- ✅ **Auto-scaling**: Handles traffic spikes
- ✅ **HTTPS**: Secure by default
- ✅ **CI/CD**: Automatic deployments from GitHub
- ✅ **Cost Effective**: Free tier eligible

### For Your Presentation:
- **Backend**: "Deployed on Azure App Service for enterprise scalability"
- **Frontend**: "Global distribution via Azure Static Web Apps CDN"
- **Database**: "Hybrid approach with Supabase + Azure readiness"
- **Security**: "HTTPS, CORS, and Azure security features"

---

## 📊 **Monitoring & Analytics**

### Add Application Insights (Optional):
1. **Create resource** → "Application Insights"
2. **Connect** to your App Service
3. **Monitor**: Performance, errors, usage

---

## 🎯 **Success Checklist**

- [ ] Backend deployed and accessible
- [ ] Frontend deployed and loading
- [ ] Environment variables configured
- [ ] CORS updated and working
- [ ] All features tested in production
- [ ] Supabase connection verified
- [ ] Voice recognition works (HTTPS enabled)
- [ ] Mobile responsive design confirmed

---

## 🚀 **Your Live URLs**

- **Application**: https://agrisync-frontend-2026.azurestaticapps.net
- **API**: https://agrisync-backend-2026.azurewebsites.net
- **Health Check**: https://agrisync-backend-2026.azurewebsites.net/api/health

**Perfect for Microsoft Imagine Cup 2026 submission!** 🏆

Your AgriSync application is now running on Microsoft Azure with enterprise-grade infrastructure, global distribution, and automatic scaling - exactly what judges want to see! 🌟