# 🚀 Deploy AgriSync Now - Step by Step

## ✅ Your App is Ready for Deployment!

I've prepared all the necessary configuration files. Here's exactly what to do:

---

## 🎯 **OPTION 1: Quick Deploy (Recommended)**

### Step 1: Deploy Backend to Railway

1. **Go to**: https://railway.app
2. **Sign up** with GitHub
3. **Click "New Project"** → **"Deploy from GitHub repo"**
4. **Select your AgriSync repository**
5. **Configure**:
   - **Root Directory**: `server`
   - **Start Command**: `npm start`
6. **Add Environment Variables**:
   ```
   PORT=5000
   JWT_SECRET=agrisync_jwt_secret_key_2024
   NODE_ENV=production
   DB_PATH=./database/agrisync.db
   OPENAI_API_KEY=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
   ```
7. **Deploy** → Copy the Railway URL (e.g., `https://agrisync-production.up.railway.app`)

### Step 2: Deploy Frontend to Vercel

1. **Go to**: https://vercel.com
2. **Sign up** with GitHub
3. **Click "New Project"** → **Import your repository**
4. **Configure**:
   - **Framework Preset**: React
   - **Root Directory**: `client`
   - **Build Command**: `npm run build`
   - **Output Directory**: `build`
5. **Add Environment Variables**:
   ```
   REACT_APP_API_URL=https://your-railway-url.up.railway.app
   REACT_APP_SUPABASE_URL=https://uqarhxopmffoyrcndccx.supabase.co
   REACT_APP_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVxYXJoeG9wbWZmb3lyY25kY2N4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcwMjYxNTksImV4cCI6MjA4MjYwMjE1OX0.eBxBSighvwEXFs2Xck93qY5sAQKb-GLqmQrRNQ054JQ
   ```
6. **Deploy** → Your app will be live!

### Step 3: Update CORS (Important!)

After deployment, update `server/index.js` line 21:
```javascript
origin: process.env.NODE_ENV === 'production' 
  ? ['https://your-vercel-app.vercel.app'] // Replace with your actual Vercel URL
  : ['http://localhost:3000'],
```

---

## 🎯 **OPTION 2: Heroku (Single Platform)**

1. **Install Heroku CLI**: https://devcenter.heroku.com/articles/heroku-cli
2. **Run these commands**:
   ```bash
   heroku create agrisync-app
   heroku config:set JWT_SECRET=agrisync_jwt_secret_key_2024
   heroku config:set NODE_ENV=production
   heroku config:set OPENAI_API_KEY=your_openai_key
   git push heroku main
   ```

---

## 🎯 **OPTION 3: Netlify + Render**

### Backend on Render:
1. **Go to**: https://render.com
2. **Create Web Service** from GitHub
3. **Root Directory**: `server`
4. **Build Command**: `npm install`
5. **Start Command**: `npm start`

### Frontend on Netlify:
1. **Go to**: https://netlify.com
2. **Deploy from GitHub**
3. **Base Directory**: `client`
4. **Build Command**: `npm run build`
5. **Publish Directory**: `client/build`

---

## 📋 **Files I've Created for You**

✅ `Procfile` - Heroku configuration
✅ `railway.json` - Railway configuration  
✅ `vercel.json` - Vercel configuration
✅ `client/.env.production` - Production environment variables
✅ `client/src/config/api.js` - API configuration
✅ Updated CORS settings in server
✅ Updated Supabase config to use environment variables

---

## 🚨 **Important Notes**

1. **Push to GitHub first** - All deployment platforms need your code on GitHub
2. **Create Supabase table** - Don't forget to run the SQL from `supabase_table_setup.sql`
3. **Update CORS origins** - Replace placeholder URLs with your actual deployment URLs
4. **Test thoroughly** - Check all features work in production

---

## 🎉 **You're Ready!**

Your AgriSync app is fully prepared for deployment. Choose your preferred option above and follow the steps. 

**Recommended**: Start with **Railway + Vercel** - it's the easiest and has generous free tiers.

Need help? The deployment should take about 10-15 minutes total!