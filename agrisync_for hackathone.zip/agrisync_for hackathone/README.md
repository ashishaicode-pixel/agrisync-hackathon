# AgriSync - Farm to Table Traceability

AgriSync empowers small producers to digitally synchronize their supply chain records with buyers through QR-based traceability. It ensures transparency, builds trust, and helps producers access premium markets by proving product origin and ethical practices.

## Features

- **QR Code Traceability**: Generate unique QR codes for each batch
- **Event Logging**: Track harvest, processing, certifications, and photos
- **Buyer Verification**: Instant product verification via QR scan
- **Trust Scoring**: Automated trust calculation based on events and certifications
- **Mobile Friendly**: Responsive design for all devices
- **Producer Dashboard**: Manage batches and view analytics

## Tech Stack

- **Frontend**: React 18, React Router, Axios, Lucide Icons
- **Backend**: Node.js, Express, SQLite
- **Authentication**: JWT tokens
- **QR Codes**: QRCode library for generation, react-qr-code for display

## Quick Start

### Prerequisites

- Node.js 16+ and npm
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd agrisync
   ```

2. **Install all dependencies**
   ```bash
   npm run install-all
   ```

3. **Start the development servers**
   ```bash
   npm run dev
   ```

This will start:
- Backend server on http://localhost:5000
- Frontend development server on http://localhost:3000

### Manual Setup (Alternative)

If the quick start doesn't work, you can set up manually:

1. **Install root dependencies**
   ```bash
   npm install
   ```

2. **Install server dependencies**
   ```bash
   cd server
   npm install
   cd ..
   ```

3. **Install client dependencies**
   ```bash
   cd client
   npm install
   cd ..
   ```

4. **Start backend server**
   ```bash
   cd server
   npm run dev
   ```

5. **Start frontend (in new terminal)**
   ```bash
   cd client
   npm start
   ```

## Usage

### For Producers

1. **Register**: Create a producer account
2. **Create Batch**: Register your harvest with details
3. **Add Events**: Log processing steps, quality checks, certifications
4. **Share QR Code**: Print and attach QR codes to products
5. **Track Scans**: Monitor buyer verification activity

### For Buyers

1. **Scan QR Code**: Use any QR scanner or camera app
2. **View Product Journey**: See complete supply chain history
3. **Verify Authenticity**: Check trust score and certifications
4. **Contact Producer**: Access producer contact information

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login

### Batches
- `GET /api/batches` - Get user's batches
- `POST /api/batches` - Create new batch
- `GET /api/batches/:id` - Get batch details
- `POST /api/batches/:id/events` - Add event to batch

### Verification
- `GET /api/verify/:batchId` - Verify batch (public)
- `GET /api/verify/:batchId/analytics` - Get scan analytics

## Database Schema

The app uses SQLite with the following main tables:

- **users**: Producer accounts and authentication
- **batches**: Product batches with QR codes
- **events**: Supply chain events and photos
- **certifications**: Product certifications
- **qr_scans**: Tracking QR code scans

## Project Structure

```
agrisync/
├── client/                 # React frontend
│   ├── public/
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── contexts/       # React contexts
│   │   ├── pages/          # Page components
│   │   └── ...
│   └── package.json
├── server/                 # Node.js backend
│   ├── database/           # Database setup
│   ├── middleware/         # Express middleware
│   ├── routes/             # API routes
│   ├── uploads/            # File uploads
│   └── package.json
└── package.json           # Root package.json
```

## Environment Variables

Create a `.env` file in the `server` directory:

```env
PORT=5000
JWT_SECRET=your_jwt_secret_key
NODE_ENV=development
DB_PATH=./database/agrisync.db
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For support, please contact the development team or create an issue in the repository.