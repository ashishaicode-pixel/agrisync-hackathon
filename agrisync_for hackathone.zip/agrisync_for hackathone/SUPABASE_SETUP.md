# Supabase Setup Instructions

## 1. Create Supabase Account
1. Go to [https://supabase.com](https://supabase.com)
2. Sign up for a free account
3. Create a new project

## 2. Get Your Credentials
1. In your Supabase dashboard, go to Settings > API
2. Copy your **Project URL** and **Anon Key**

## 3. Update Configuration
Open `client/src/config/supabase.js` and replace:
```javascript
const supabaseUrl = 'YOUR_SUPABASE_URL_HERE';
const supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY_HERE';
```

With your actual credentials:
```javascript
const supabaseUrl = 'https://your-project-id.supabase.co';
const supabaseAnonKey = 'your-anon-key-here';
```

## 4. Create Database Table
In your Supabase dashboard, go to SQL Editor and run this query:

```sql
CREATE TABLE crops (
  id SERIAL PRIMARY KEY,
  product_name VARCHAR(255) NOT NULL,
  product_type VARCHAR(100),
  quantity DECIMAL(10,2),
  unit VARCHAR(50),
  price DECIMAL(10,2),
  harvest_date DATE,
  location VARCHAR(255),
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security (optional)
ALTER TABLE crops ENABLE ROW LEVEL SECURITY;

-- Create a policy to allow all operations (for development)
CREATE POLICY "Allow all operations" ON crops FOR ALL USING (true);
```

## 5. Test the Integration
1. Start your application
2. Go to Create New Batch page
3. Try creating a batch - it should save to both local database and Supabase
4. Check your Supabase dashboard to see the data

## Voice Recognition Features
- Click the microphone button to start voice recognition
- Say phrases like: "50 kg of Potatoes price 20 rupees"
- The system will auto-fill Product Name, Quantity, Unit, and Price fields
- Supports English voice commands
- Works in modern browsers (Chrome, Firefox, Safari)

## Troubleshooting
- If Supabase fails, the app will still save to local database
- Voice recognition requires HTTPS in production
- Make sure your browser supports Web Speech API