# AgriSync Azure Deployment Script for Microsoft Imagine Cup 2026
# PowerShell script for Windows deployment

Write-Host "🚀 AgriSync Azure Deployment for Microsoft Imagine Cup 2026" -ForegroundColor Green
Write-Host "=================================================" -ForegroundColor Green

# Check if Azure CLI is installed
try {
    az --version | Out-Null
    Write-Host "✅ Azure CLI is installed" -ForegroundColor Green
} catch {
    Write-Host "❌ Azure CLI not found. Please install from: https://aka.ms/installazurecliwindows" -ForegroundColor Red
    exit 1
}

# Login to Azure
Write-Host "🔐 Logging into Azure..." -ForegroundColor Yellow
az login

# Set variables
$resourceGroup = "agrisync-rg"
$location = "East US"
$backendAppName = "agrisync-backend-$(Get-Random -Minimum 1000 -Maximum 9999)"
$frontendAppName = "agrisync-frontend-$(Get-Random -Minimum 1000 -Maximum 9999)"
$planName = "agrisync-plan"

Write-Host "📋 Deployment Configuration:" -ForegroundColor Cyan
Write-Host "Resource Group: $resourceGroup" -ForegroundColor White
Write-Host "Location: $location" -ForegroundColor White
Write-Host "Backend App: $backendAppName" -ForegroundColor White
Write-Host "Frontend App: $frontendAppName" -ForegroundColor White

# Create resource group
Write-Host "🏗️ Creating resource group..." -ForegroundColor Yellow
az group create --name $resourceGroup --location $location

# Create App Service plan
Write-Host "📦 Creating App Service plan..." -ForegroundColor Yellow
az appservice plan create --name $planName --resource-group $resourceGroup --sku B1 --is-linux

# Create backend web app
Write-Host "🖥️ Creating backend web app..." -ForegroundColor Yellow
az webapp create --resource-group $resourceGroup --plan $planName --name $backendAppName --runtime "NODE|18-lts"

# Configure backend environment variables
Write-Host "⚙️ Configuring backend environment variables..." -ForegroundColor Yellow
az webapp config appsettings set --resource-group $resourceGroup --name $backendAppName --settings `
  PORT=8080 `
  JWT_SECRET=agrisync_jwt_secret_key_2024 `
  NODE_ENV=production `
  DB_PATH=./database/agrisync.db `
  OPENAI_API_KEY=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 `
  WEBSITE_NODE_DEFAULT_VERSION=18.17.0

# Build and deploy backend
Write-Host "🔨 Building and deploying backend..." -ForegroundColor Yellow
Push-Location server
Compress-Archive -Path * -DestinationPath ../backend.zip -Force
Pop-Location
az webapp deployment source config-zip --resource-group $resourceGroup --name $backendAppName --src backend.zip

# Get backend URL
$backendUrl = "https://$backendAppName.azurewebsites.net"

Write-Host "✅ Backend deployed successfully!" -ForegroundColor Green
Write-Host "Backend URL: $backendUrl" -ForegroundColor Cyan

# Build frontend
Write-Host "🔨 Building frontend..." -ForegroundColor Yellow
Push-Location client

# Update environment variables for production
$envContent = @"
REACT_APP_API_URL=$backendUrl
REACT_APP_SUPABASE_URL=https://uqarhxopmffoyrcndccx.supabase.co
REACT_APP_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVxYXJoeG9wbWZmb3lyY25kY2N4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcwMjYxNTksImV4cCI6MjA4MjYwMjE1OX0.eBxBSighvwEXFs2Xck93qY5sAQKb-GLqmQrRNQ054JQ
"@
$envContent | Out-File -FilePath ".env.production" -Encoding UTF8

npm install
npm run build
Pop-Location

# Create Static Web App
Write-Host "🌐 Creating Static Web App..." -ForegroundColor Yellow
az extension add --name staticwebapp
az staticwebapp create `
  --name $frontendAppName `
  --resource-group $resourceGroup `
  --location "East US 2" `
  --source "https://github.com/yourusername/agrisync" `
  --branch main `
  --app-location "client" `
  --output-location "build"

$frontendUrl = "https://$frontendAppName.azurestaticapps.net"

Write-Host "🎉 Deployment Complete!" -ForegroundColor Green
Write-Host "=================================================" -ForegroundColor Green
Write-Host "✅ Backend URL: $backendUrl" -ForegroundColor Cyan
Write-Host "✅ Frontend URL: $frontendUrl" -ForegroundColor Cyan
Write-Host ""
Write-Host "📋 Next Steps:" -ForegroundColor Yellow
Write-Host "1. Update CORS in server/index.js with frontend URL" -ForegroundColor White
Write-Host "2. Create Supabase table using supabase_table_setup.sql" -ForegroundColor White
Write-Host "3. Test all functionality on production URLs" -ForegroundColor White
Write-Host "4. Submit to Microsoft Imagine Cup 2026! 🏆" -ForegroundColor White

# Clean up
Remove-Item backend.zip -ErrorAction SilentlyContinue

Write-Host "🚀 Your AgriSync app is live on Microsoft Azure!" -ForegroundColor Green