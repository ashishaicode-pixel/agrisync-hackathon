#!/bin/bash

# AgriSync Deployment Script

echo "🚀 Starting AgriSync Deployment Process..."

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "📝 Initializing Git repository..."
    git init
    git add .
    git commit -m "Initial commit - AgriSync MVP ready for deployment"
fi

echo "✅ Git repository ready"

# Build client for production
echo "🔨 Building client for production..."
cd client
npm install
npm run build
cd ..

echo "✅ Client build completed"

# Test server
echo "🧪 Testing server..."
cd server
npm install
npm test 2>/dev/null || echo "⚠️  No tests found, skipping..."
cd ..

echo "✅ Server ready"

echo "🎉 Deployment preparation complete!"
echo ""
echo "📋 Next Steps:"
echo "1. Push your code to GitHub"
echo "2. Deploy backend to Railway: https://railway.app"
echo "3. Deploy frontend to Vercel: https://vercel.com"
echo "4. Update CORS origins in server/index.js with your production URLs"
echo ""
echo "🔗 Useful Links:"
echo "- Railway: https://railway.app"
echo "- Vercel: https://vercel.com"
echo "- Deployment Guide: ./DEPLOYMENT_GUIDE_2024.md"