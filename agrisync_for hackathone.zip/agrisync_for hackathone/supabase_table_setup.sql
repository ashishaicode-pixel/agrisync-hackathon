-- Create the crops table in your Supabase dashboard
-- Go to SQL Editor in Supabase and run this query:

CREATE TABLE IF NOT EXISTS crops (
  id SERIAL PRIMARY KEY,
  product_name VARCHAR(255) NOT NULL,
  product_type VARCHAR(100),
  quantity DECIMAL(10,2),
  unit VARCHAR(50),
  price DECIMAL(10,2),
  harvest_date DATE,
  location VARCHAR(255),
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security (optional for development)
ALTER TABLE crops ENABLE ROW LEVEL SECURITY;

-- Create a policy to allow all operations (for development)
-- In production, you should create more restrictive policies
CREATE POLICY "Allow all operations on crops" ON crops 
FOR ALL 
USING (true) 
WITH CHECK (true);

-- Grant permissions to authenticated users
GRANT ALL ON crops TO authenticated;
GRANT ALL ON crops TO anon;

-- Grant sequence permissions
GRANT USAGE, SELECT ON SEQUENCE crops_id_seq TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE crops_id_seq TO anon;