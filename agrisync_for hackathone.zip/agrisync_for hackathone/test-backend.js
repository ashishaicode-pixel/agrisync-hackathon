const http = require('http');

// Test backend health endpoint
const options = {
  hostname: 'localhost',
  port: 5000,
  path: '/api/health',
  method: 'GET'
};

console.log('🧪 Testing AgriSync Backend...');

const req = http.request(options, (res) => {
  console.log(`✅ Status Code: ${res.statusCode}`);
  console.log(`✅ Headers:`, res.headers);
  
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log('✅ Response:', data);
    console.log('🎉 Backend is working properly!');
    process.exit(0);
  });
});

req.on('error', (e) => {
  console.error(`❌ Backend test failed: ${e.message}`);
  process.exit(1);
});

req.end();