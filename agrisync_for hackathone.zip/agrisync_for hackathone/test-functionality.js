const http = require('http');

console.log('🧪 Testing AgriSync Functionality...\n');

// Test functions
const testEndpoint = (path, method = 'GET', data = null) => {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 5000,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let responseData = '';
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        resolve({
          status: res.statusCode,
          data: responseData
        });
      });
    });

    req.on('error', (e) => {
      reject(e);
    });

    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
};

// Run tests
async function runTests() {
  try {
    // Test 1: Health check
    console.log('1. Testing health endpoint...');
    const health = await testEndpoint('/api/health');
    console.log(`   Status: ${health.status} - ${health.status === 200 ? '✅ PASS' : '❌ FAIL'}`);
    
    // Test 2: Marketplace endpoint
    console.log('2. Testing marketplace endpoint...');
    const marketplace = await testEndpoint('/api/marketplace');
    console.log(`   Status: ${marketplace.status} - ${marketplace.status === 200 ? '✅ PASS' : '❌ FAIL'}`);
    const marketplaceData = JSON.parse(marketplace.data);
    console.log(`   Found ${marketplaceData.length} products in marketplace`);
    
    // Test 3: Quote endpoint (POST)
    console.log('3. Testing quote request endpoint...');
    const quoteData = {
      productId: 'test-123',
      productName: 'Test Product',
      producer: 'Test Producer',
      companyName: 'Test Company',
      contactName: 'Test Contact',
      email: 'test@example.com',
      phone: '1234567890',
      quantity: 10,
      message: 'Test quote request'
    };
    
    const quote = await testEndpoint('/api/quotes', 'POST', quoteData);
    console.log(`   Status: ${quote.status} - ${quote.status === 201 ? '✅ PASS' : '❌ FAIL'}`);
    
    console.log('\n🎉 All basic functionality tests completed!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

runTests();